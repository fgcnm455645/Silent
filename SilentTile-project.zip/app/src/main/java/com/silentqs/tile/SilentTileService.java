package com.silentqs.tile;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Icon;
import android.media.AudioManager;
import android.os.Build;
import android.provider.Settings;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;
import android.widget.Toast;

public class SilentTileService extends TileService {

    private boolean registered = false;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            refresh();
        }
    };

    @Override
    public void onStartListening() {
        if (!registered) {
            IntentFilter f = new IntentFilter(AudioManager.RINGER_MODE_CHANGED_ACTION);
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
            } else {
                registerReceiver(receiver, f);
            }
            registered = true;
        }
        refresh();
    }

    @Override
    public void onStopListening() {
        if (registered) {
            try {
                unregisterReceiver(receiver);
            } catch (Exception ignored) {
            }
            registered = false;
        }
    }

    @Override
    public void onTileAdded() {
        refresh();
    }

    @Override
    public void onClick() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm == null || !nm.isNotificationPolicyAccessGranted()) {
            openAccessSettings();
            return;
        }
        AudioManager am = getSystemService(AudioManager.class);
        try {
            if (am.getRingerMode() == AudioManager.RINGER_MODE_SILENT) {
                am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            } else {
                am.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            }
        } catch (SecurityException e) {
            openAccessSettings();
            return;
        }
        refresh();
    }

    private void refresh() {
        Tile tile = getQsTile();
        if (tile == null) return;
        AudioManager am = getSystemService(AudioManager.class);
        boolean silent = am.getRingerMode() == AudioManager.RINGER_MODE_SILENT;
        tile.setState(silent ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setIcon(Icon.createWithResource(this,
                silent ? R.drawable.ic_silent_on : R.drawable.ic_silent_off));
        tile.setLabel("Silent");
        tile.updateTile();
    }

    private void openAccessSettings() {
        Toast.makeText(this, "Allow Silent Tile in Do Not Disturb access", Toast.LENGTH_LONG).show();
        Intent i = new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (Build.VERSION.SDK_INT >= 34) {
            PendingIntent pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE);
            startActivityAndCollapse(pi);
        } else {
            startActivityAndCollapse(i);
        }
    }
}
